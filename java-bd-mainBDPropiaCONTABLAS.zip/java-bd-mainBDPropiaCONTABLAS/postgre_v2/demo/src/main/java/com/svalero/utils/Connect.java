package com.svalero.utils;

public class Connect {
    public static final String USER = "postgre";
    public static final String PASSWORD = "12341234";
}
