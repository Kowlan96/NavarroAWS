package com.svalero;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import com.svalero.utils.Connect;
import com.svalero.utils.MotorSQL;

/**
 * Hello world!
 *
 */
public class App {
    public static void main(String[] args) throws SQLException {

        // Connection
        // Connection conn = DriverManager.getConnection(url, user, password);
        
        //String sql = "SELECT * FROM USUARIOS";

        MotorSQL motor1 = new MotorSQL();


        /*motor1 = null;
        stmt = motor1.ejecutarSentencia("CREATE TABLE paises (pais varchar(50) NOT NULL, acronimo CHAR(3), poblacion INT(20))");*/


        motor1.connect();
        motor1.ejecutarSentencia("CREATE TABLE ALUMNOS (num_mat integer not null);");

        motor1.ejecutarSentencia("INSERT INTO ALUMNOS VALUES (1);");

        motor1.ejecutarSentenciaConDatos("SELECT * FROM ALUMNOS");


        motor1.disconnect();



        // Statement
        // Resultset

        System.out.println("Hello World!");
    }
}