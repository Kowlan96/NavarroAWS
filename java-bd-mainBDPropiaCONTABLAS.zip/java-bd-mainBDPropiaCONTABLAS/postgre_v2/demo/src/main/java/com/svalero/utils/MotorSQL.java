package com.svalero.utils;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

public class MotorSQL {
    /*private Connection conexion;*/
    public Connection conn;
    private Statement sentenciaSQL;
    private ResultSet datosDB;

    String URL = "jdbc:postgresql://postgre.cp08w2iac2as.us-east-1.rds.amazonaws.com/postgres";

    public void connect() {
        Properties properties = new Properties();
        properties.setProperty("user", Connect.USER);
        properties.setProperty("password", Connect.PASSWORD);
        properties.setProperty("ssl", "false");

        try {
            this.conn = DriverManager.getConnection(URL, properties);
            if (conn != null) {
                System.out.println("Conectado a la Base de Datos");
            }

           /*ResultSet rs = (ResultSet) stm.executeQuery(consulta);

            while (rs.next()) { //
                // int id = rs.getInt(1);
                System.out.println("Hay registros!!!!");
                String name1 = rs.getString(1);
                // int id = rs.getInt(2);
                System.out.println("name=>" + name1);
                // System.out.println(id + " " + name);
            }*/

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            // e.printStackTrace();
            System.out.println(e.getMessage());
        }
    }

    public void disconnect(){

    }
    public boolean ejecutarSentencia(String SQL){
        boolean resp = false;
        try {
            sentenciaSQL = this.conn.createStatement();
            System.out.println("Holiwi");
            resp = sentenciaSQL.execute(SQL);
            /*if (resp != null) {
                resp = true;
            }*/
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            throw new RuntimeException(e);
        }finally {
            System.out.println(resp);
            return resp;
        }

    }
    public ResultSet ejecutarSentenciaConDatos(String SQL){ // SELECT * FROM PELICULAS, ...
        try {
            sentenciaSQL = this.conn.createStatement();
            this.datosDB =  sentenciaSQL.executeQuery(SQL);
            System.out.println("Holiwi");
            while(datosDB.next()){
                System.out.println("Hay registros ticher");
                int num = datosDB.getInt(1);
                System.out.println("num_mat: " + num);

            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally {
            return this.datosDB;
        }
    }

    
}
